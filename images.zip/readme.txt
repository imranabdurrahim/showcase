# Introduction :
=====================

Opart is an one page responsive template .This template can be used for any kinds of website like business , personal, portfolio, gallery etc.
This template is easy to use and simple to edit . Made with twitter bootstrap with valid css3, HTML5, and Javascript .

Author : Imran Abdur Rahim
Mail : imranabdurrahim@gmail.com

Note1: Please report me if you see any bug.
Note2: Don't hesitate to contact with me if you face any problem to install the template.

# Version :
=====================
Number : 1.0
This is first version of this template.

# Credit :
=====================
1-> bootstrap
2-> jQuery
3-> Lightbox jquery plugin
4-> TheStocks.im best royalty free stock photos


########################### User Guidelines #######################

# Add background image 
======================
Simply add image in " assets\img\layout " folder and rename the picture with the name " bg.jpg " ( which is already be there ).

# Navigation Menu
=====================
To add any menu just copy one of <li> item and place it between <ul> section . If you want to edit text just edit text between <li> and </li>
section. And in href just mention your column ( div ) to scroll that specific column (div).

*** Give attention while change anything to the " href " . Give correct div ( column ) name to scroll down .

# Lead text 
=====================
To add and edit text in lead column all you need to do just replace with dummy text in lead column ( lead div ) which is separated by
comment sign and text

# service 
=====================
Every "<div class="col-xs-12 col-sm-4">" div has a specific Modal item which always show on click . Just copy entire div and paste to add more.
And Just edit the demo text with your one of these divs ( columns ).

# Portfolio 
=====================
Edit the "href" and "src" tag with same image source file you wanna show. And just copy " <div class="col-xs-6 col-md-3"> " to add
more portfolio image.

# Latest project
=====================
Latest project section is same as service section . Just copy one of " <div class="col-xs-12 col-sm-6 col-md-3"> " div . 
And pay attention to modal section of every div

# clients
====================
Add more client by copy this "<div class="item">" div and to delete any of this div you wanna to delete .
Whenever delete one or add more div please delete or add item in indicators section . All you need to do just copy or delete elements from there.

And replace clients logo or add or edit with your image. And to add more just copy any of " <div class="col-xs-6 col-sm-3"> " div .

# Contact 
===================
Edit dummy content with your own .

# Footer 
===================
Add content with your own .

And in latest project section please be careful to the data-target attribute . Change this with same name in upper latest project section.
To add more latest project in footer , Just copy one of " <a data-toggle="modal" " . And mention the specific upper latest project's data-target.

Change "href" with your social connection address . Just copy or delete any of <li> item in social network connection section.

# copyright 
==================
Change content with your own and change the image address with your logo address .
